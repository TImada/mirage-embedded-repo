# conf-frt

This package provides configuration functionality to select a processor for which FreeRTOS-based binding/tender layers in Solo5 are built.
